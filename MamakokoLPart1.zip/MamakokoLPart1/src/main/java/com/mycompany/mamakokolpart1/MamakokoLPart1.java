/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mamakokolpart1;

/**
 *
 * @author lehlogonolo
 */
import java.util.Scanner;
public class MamakokoLPart1 {

    public static void main(String[] args) {
        //Declarations
        String firstName;
        String lastName;
        String userName;
        String password;
        String cellPhoneNumber;
        String registerUserName;
        String registerPassword;

        Scanner input = new Scanner(System.in);

        // REGISTRATION

        // Ask user for first name
        System.out.print("Please enter your first name: ");
        firstName = input.nextLine();

        // Ask user for last name
        System.out.print("Please enter your last name: ");
        lastName = input.nextLine();

        // Ask user for username
        System.out.print("Please enter your username: ");
        userName = input.nextLine();

        // Check username
        while (!Login.checkUserName(userName)) {

            System.out.println("Username is not correctly formatted; "
                    + "please ensure that your username contains an "
                    + "underscore and is no more than five characters "
                    + "in length.");

            System.out.print("Please enter your username again: ");
            userName = input.nextLine();
        }

        System.out.println("Username successfully captured.");

        // Ask user for password
        System.out.print("Please enter your password: ");
        password = input.nextLine();

        // Check password
        while (!Login.checkPasswordComplexity(password)) {

            System.out.println("Password is not correctly formatted; "
                    + "please ensure that the password contains at "
                    + "least eight characters, a capital letter, "
                    + "a number, and a special character");

            System.out.print("Please enter your password again: ");
            password = input.nextLine();
        }

        System.out.println("Password successfully captured.");

        // Ask user for cellphone number
        System.out.print("Please enter your cellphone Number: ");
        cellPhoneNumber = input.nextLine();

        // Check cellphone number
        while (!Login.checkCellPhoneNumber(cellPhoneNumber)) {
            System.out.println(
                    "Cell number is incorrectly formatted or does "
                    + "not contain an international code; please "
                    + "correct the number and try again."
            );
            System.out.print("Please enter your cellphone Number again: ");
            cellPhoneNumber = input.nextLine();
        }

        System.out.println("Cell number successfully captured.");

        // Registration method
        System.out.println(
                Login.registerUser(
                        userName,
                        password,
                        cellPhoneNumber
                )
        );

        // LOGIN

        // Ask for username
        System.out.print("Please enter your username: ");
        registerUserName = input.nextLine();

        // Ask for password
        System.out.print("Please enter your password: ");
        registerPassword = input.nextLine();

        // Check login
        boolean loginSuccessful =
                Login.loginUser(
                        registerUserName,
                        registerPassword,
                        userName,
                        password);

        // Display login status
        System.out.println(
                Login.returnLoginStatus(
                        loginSuccessful,
                        firstName,
                        lastName
                )
        );

        input.close();
    }
}

public class Login {

    //Check username
    public static boolean checkUserName(String userName) {
        if (userName.contains("_")
                && userName.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    //  Check password complexity
    public static boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        int index = 0;

        while (index < password.length()) {
            char current = password.charAt(index);
            if (Character.isUpperCase(current)) {
                hasCapitalLetter = true;
            } else if (Character.isDigit(current)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(current)) {
                hasSpecialCharacter = true;
            }

            index++;
        }

        if (hasCapitalLetter
                && hasNumber
                && hasSpecialCharacter) {
            return true;
        } else {
            return false;
        }
    }

    // Check cellphone number
    public static boolean checkCellPhoneNumber(
            String cellPhoneNumber) {

        if (cellPhoneNumber.matches("\\+27[0-9]{9}")) {
            return true;
        } else {
            return false;
        }
    }

    // Registration method
    public static String registerUser(
            String userName,
            String password,
            String cellPhoneNumber) {

        if (!checkUserName(userName)) {

            return "Username is not correctly formatted; "
                    + "please ensure that your username contains an "
                    + "underscore and is no more than five characters "
                    + "in length.";

        } else if (!checkPasswordComplexity(password)) {

            return "Password is not correctly formatted; "
                    + "please ensure that the password contains at "
                    + "least eight characters, a capital letter, "
                    + "a number, and a special character.";

        } else if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell number is incorrectly formatted or does "
                    + "not contain an international code; please "
                    + "correct the number and try again.";
        } else {
            return "User registered successfully.";
        }
    }

    // Login method
    public static boolean loginUser(
            String enteredUserName,
            String enteredPassword,
            String userName,
            String password) {
        
        if (enteredUserName.equals(userName)
                && enteredPassword.equals(password)) {

            return true;
        } else {
            return false;
        }
    }

    // Return login status
    public static String returnLoginStatus(
            boolean login,
            String firstName,
            String lastName) {

        if (login) {
            return "Welcome " + firstName + ", "+ lastName + " it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}


    
